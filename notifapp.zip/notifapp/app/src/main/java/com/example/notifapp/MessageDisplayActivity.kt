package com.example.notifapp

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MessageDisplayActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_message_display)

        // Retrieve the message from the Intent
        val message = intent.getStringExtra("message_data")

        // Display the message
        val textView = findViewById<TextView>(R.id.messageTextView)
        textView.text = message
    }
}
